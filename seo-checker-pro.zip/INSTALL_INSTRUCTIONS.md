# ⚠️ STOP! READ THIS CAREFULLY ⚠️

## You Keep Loading the WRONG Folder!

### ❌ WRONG Folders (DO NOT LOAD THESE):
- `promptblaze-advanced` ❌
- `seo-checker-landing` ❌
- Any other folder ❌

### ✅ CORRECT Folder (LOAD THIS ONE):
- `seo-checker-pro` ✅

---

## Step-by-Step Installation

### Step 1: Download & Extract
1. Download the file: `seo-checker-pro.zip`
2. **Extract it** (unzip it)
3. You should see a folder named: **seo-checker-pro**

### Step 2: Verify the Folder
Open the `seo-checker-pro` folder and check it contains:
- ✅ `manifest.json` (THIS FILE MUST BE THERE!)
- ✅ `popup.html`
- ✅ `icons/` folder
- ✅ `scripts/` folder
- ✅ `styles/` folder

**If you don't see `manifest.json`, you're in the WRONG folder!**

### Step 3: Load in Chrome
1. Open Chrome
2. Go to: `chrome://extensions/`
3. Enable "Developer mode" (toggle in top-right corner)
4. Click "Load unpacked"
5. **Navigate to and SELECT the folder: `seo-checker-pro`**
   - NOT `promptblaze-advanced`
   - NOT `seo-checker-landing`
   - NOT any other folder
   - ONLY `seo-checker-pro`
6. Click "Select Folder"

### Step 4: Verify Installation
You should see:
- Extension name: "Sean Guillermo AIO Tools - SEO Checker"
- Extension icon: Green/Red/Yellow/Gray "S" circle
- No errors

---

## Troubleshooting

### Error: "Manifest file is missing or unreadable"
**Cause:** You selected the wrong folder!

**Solution:**
1. Make sure you extracted the ZIP file first
2. Look for the folder named `seo-checker-pro`
3. Open it and verify `manifest.json` is inside
4. Select THIS folder when loading

### Still Having Issues?
1. Delete all old extension folders
2. Re-download `seo-checker-pro.zip`
3. Extract it to a clean location (like Desktop)
4. Follow steps above exactly

---

## What Each Folder Is For

| Folder Name | What It Is | Should You Load It? |
|-------------|-----------|---------------------|
| `seo-checker-pro` | The Chrome Extension | ✅ YES - LOAD THIS! |
| `seo-checker-landing` | Website/Landing Page | ❌ NO |
| `promptblaze-advanced` | Different Extension | ❌ NO |

---

## Final Check Before Loading

Before clicking "Load unpacked", ask yourself:
1. ✅ Did I extract the ZIP file?
2. ✅ Am I in the `seo-checker-pro` folder?
3. ✅ Can I see `manifest.json` inside?

If all answers are YES, then proceed!

---

**The extension is ready and working. You just need to load the CORRECT folder!**

- Sean Guillermo AIO Tools Team

