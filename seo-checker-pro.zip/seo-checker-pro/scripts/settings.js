// SEO Checker Pro - Settings Script

// Load settings on page load
document.addEventListener('DOMContentLoaded', () => {
  loadSettings();
  setupEventListeners();
});

// Load settings from storage
async function loadSettings() {
  const response = await chrome.runtime.sendMessage({ action: 'getSettings' });
  const settings = response.settings;
  
  document.getElementById('autoCheck').checked = settings.autoCheck;
  document.getElementById('autoHighlightLinks').checked = settings.autoHighlightLinks;
  document.getElementById('autoHighlightHeadings').checked = settings.autoHighlightHeadings;
  document.getElementById('cacheEnabled').checked = settings.cacheEnabled;
  document.getElementById('cacheDuration').value = settings.cacheDuration;
}

// Setup event listeners
function setupEventListeners() {
  // Save button
  document.getElementById('saveBtn').addEventListener('click', saveSettings);
  
  // Clear cache button
  document.getElementById('clearCacheBtn').addEventListener('click', clearCache);
}

// Save settings
async function saveSettings() {
  const settings = {
    autoCheck: document.getElementById('autoCheck').checked,
    autoHighlightLinks: document.getElementById('autoHighlightLinks').checked,
    autoHighlightHeadings: document.getElementById('autoHighlightHeadings').checked,
    cacheEnabled: document.getElementById('cacheEnabled').checked,
    cacheDuration: parseInt(document.getElementById('cacheDuration').value)
  };
  
  await chrome.runtime.sendMessage({
    action: 'updateSettings',
    settings: settings
  });
  
  showToast('Settings saved successfully!');
}

// Clear cache
async function clearCache() {
  await chrome.runtime.sendMessage({ action: 'clearCache' });
  showToast('Cache cleared successfully!');
}

// Show toast notification
function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

