// SEO Checker Pro - Content Script
// Handles on-page highlighting for headings and links

let headingsHighlighted = false;
let linksHighlighted = false;

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'toggleHeadings') {
    toggleHeadingsHighlight();
    sendResponse({ success: true, active: headingsHighlighted });
  }
  
  if (request.action === 'toggleLinks') {
    toggleLinksHighlight();
    sendResponse({ success: true, active: linksHighlighted });
  }
  
  if (request.action === 'checkLinks') {
    checkAllLinks().then(results => {
      sendResponse({ success: true, results: results });
    });
    return true; // Async response
  }
  
  return true;
});

// Toggle headings highlight
function toggleHeadingsHighlight() {
  if (headingsHighlighted) {
    removeHeadingsHighlight();
  } else {
    highlightHeadings();
  }
}

// Highlight all headings
function highlightHeadings() {
  const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
  
  headings.forEach(heading => {
    const tag = heading.tagName.toLowerCase();
    heading.classList.add('seo-checker-heading');
    heading.classList.add(`seo-checker-${tag}`);
    
    // Add label
    const label = document.createElement('span');
    label.className = 'seo-checker-label';
    label.textContent = tag.toUpperCase();
    label.style.cssText = `
      position: absolute;
      top: -20px;
      left: 0;
      background: ${getHeadingColor(tag)};
      color: white;
      padding: 2px 6px;
      font-size: 10px;
      font-weight: bold;
      border-radius: 3px;
      z-index: 999999;
    `;
    
    // Make heading position relative if not already
    const position = window.getComputedStyle(heading).position;
    if (position === 'static') {
      heading.style.position = 'relative';
    }
    
    heading.appendChild(label);
  });
  
  headingsHighlighted = true;
}

// Remove headings highlight
function removeHeadingsHighlight() {
  const headings = document.querySelectorAll('.seo-checker-heading');
  
  headings.forEach(heading => {
    heading.classList.remove('seo-checker-heading');
    heading.classList.remove('seo-checker-h1', 'seo-checker-h2', 'seo-checker-h3', 'seo-checker-h4', 'seo-checker-h5', 'seo-checker-h6');
    
    const label = heading.querySelector('.seo-checker-label');
    if (label) {
      label.remove();
    }
  });
  
  headingsHighlighted = false;
}

// Get heading color
function getHeadingColor(tag) {
  const colors = {
    h1: '#eb5757',
    h2: '#f2994a',
    h3: '#f2c94c',
    h4: '#6fcf97',
    h5: '#56ccf2',
    h6: '#9b51e0'
  };
  return colors[tag] || '#9ca3af';
}

// Toggle links highlight
function toggleLinksHighlight() {
  if (linksHighlighted) {
    removeLinksHighlight();
  } else {
    highlightLinks();
  }
}

// Highlight all links
async function highlightLinks() {
  const links = document.querySelectorAll('a[href]');
  
  for (const link of links) {
    link.classList.add('seo-checker-link');
    
    // Check link status
    const status = await checkLinkStatus(link.href);
    
    // Apply color based on status
    let color = '#00d084'; // Green - working
    let label = 'OK';
    
    if (status.broken) {
      color = '#eb5757'; // Red - broken
      label = `${status.code || 'ERR'}`;
    } else if (status.redirect) {
      color = '#f2994a'; // Orange - redirect
      label = `${status.code}`;
    }
    
    // Check if internal or external
    const isInternal = link.hostname === window.location.hostname;
    const borderStyle = isInternal ? 'solid' : 'dashed';
    
    link.style.cssText = `
      outline: 2px ${borderStyle} ${color} !important;
      outline-offset: 2px !important;
      position: relative !important;
    `;
    
    // Add status label
    const statusLabel = document.createElement('span');
    statusLabel.className = 'seo-checker-link-label';
    statusLabel.textContent = label;
    statusLabel.style.cssText = `
      position: absolute;
      top: -18px;
      left: 0;
      background: ${color};
      color: white;
      padding: 1px 4px;
      font-size: 9px;
      font-weight: bold;
      border-radius: 2px;
      z-index: 999999;
      white-space: nowrap;
    `;
    
    link.appendChild(statusLabel);
  }
  
  linksHighlighted = true;
}

// Remove links highlight
function removeLinksHighlight() {
  const links = document.querySelectorAll('.seo-checker-link');
  
  links.forEach(link => {
    link.classList.remove('seo-checker-link');
    link.style.outline = '';
    link.style.outlineOffset = '';
    
    const label = link.querySelector('.seo-checker-link-label');
    if (label) {
      label.remove();
    }
  });
  
  linksHighlighted = false;
}

// Check link status
async function checkLinkStatus(url) {
  try {
    const response = await fetch(url, {
      method: 'HEAD',
      mode: 'no-cors',
      cache: 'no-cache'
    });
    
    return {
      code: response.status,
      ok: response.ok,
      broken: !response.ok && response.status >= 400,
      redirect: response.redirected || (response.status >= 300 && response.status < 400)
    };
  } catch (error) {
    return {
      code: null,
      ok: false,
      broken: true,
      redirect: false,
      error: error.message
    };
  }
}

// Check all links and return results
async function checkAllLinks() {
  const links = document.querySelectorAll('a[href]');
  const results = [];
  
  for (const link of links) {
    const status = await checkLinkStatus(link.href);
    results.push({
      url: link.href,
      text: link.textContent.trim(),
      isInternal: link.hostname === window.location.hostname,
      ...status
    });
  }
  
  return results;
}

