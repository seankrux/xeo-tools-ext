// SEO Checker Pro - Background Service Worker
// Handles auto-analysis, caching, icon updates, and badge management

const analysisCache = new Map();
let settings = {
  autoCheck: true,
  cacheDuration: 3600000, // 1 hour in milliseconds
  cacheEnabled: true,
  autoHighlightLinks: false,
  autoHighlightHeadings: false
};

// Load settings from storage
chrome.storage.sync.get('settings', (data) => {
  if (data.settings) {
    settings = { ...settings, ...data.settings };
  }
});

// Listen for settings changes
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'sync' && changes.settings) {
    settings = { ...settings, ...changes.settings.newValue };
  }
});

// Tab update listener - auto-analyze on page load
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading') {
    // Reset icon when page starts loading
    updateIcon(tabId, 'gray', 0);
  }
  
  if (changeInfo.status === 'complete' && tab.url) {
    if (settings.autoCheck && isAnalyzableUrl(tab.url)) {
      analyzePage(tabId, tab.url);
    }
  }
});

// Tab activation listener - update icon when switching tabs
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const tab = await chrome.tabs.get(activeInfo.tabId);
  if (tab.url && isAnalyzableUrl(tab.url)) {
    // Check if we have cached data
    const cached = getCachedAnalysis(tab.url);
    if (cached) {
      updateIconFromAnalysis(activeInfo.tabId, cached);
    } else {
      // Check storage for analysis
      const key = `analysis_${activeInfo.tabId}`;
      const stored = await chrome.storage.local.get(key);
      if (stored[key]) {
        updateIconFromAnalysis(activeInfo.tabId, stored[key]);
      } else if (settings.autoCheck) {
        analyzePage(activeInfo.tabId, tab.url);
      } else {
        updateIcon(activeInfo.tabId, 'gray', 0);
      }
    }
  } else {
    updateIcon(activeInfo.tabId, 'gray', 0);
  }
});

// Navigation listener - detect when user navigates to new URL in same tab
chrome.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId === 0) { // Main frame only
    const url = details.url;
    if (isAnalyzableUrl(url)) {
      updateIcon(details.tabId, 'gray', '...');
      if (settings.autoCheck) {
        // Small delay to let page start loading
        setTimeout(() => {
          analyzePage(details.tabId, url);
        }, 500);
      }
    } else {
      updateIcon(details.tabId, 'gray', 0);
    }
  }
});

// Check if URL can be analyzed
function isAnalyzableUrl(url) {
  return url && (url.startsWith('http://') || url.startsWith('https://'));
}

// Get cached analysis if valid
function getCachedAnalysis(url) {
  if (!settings.cacheEnabled) return null;
  
  const cached = analysisCache.get(url);
  if (!cached) return null;
  
  const age = Date.now() - cached.timestamp;
  if (age > settings.cacheDuration) {
    analysisCache.delete(url);
    return null;
  }
  
  return cached.data;
}

// Cache analysis results
function cacheAnalysis(url, data) {
  if (!settings.cacheEnabled) return;
  
  analysisCache.set(url, {
    data: data,
    timestamp: Date.now()
  });
  
  // Also store in chrome.storage for persistence
  chrome.storage.local.set({
    [`cache_${url}`]: {
      data: data,
      timestamp: Date.now()
    }
  });
}

// Main analysis function
async function analyzePage(tabId, url) {
  try {
    // Show analyzing state
    updateIcon(tabId, 'gray', '...');
    
    // Inject content script and get page data
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: extractPageData
    });
    
    if (!results || !results[0]) {
      throw new Error('Failed to extract page data');
    }
    
    const pageData = results[0].result;
    
    // Perform SEO analysis
    const analysis = await performSEOAnalysis(url, pageData, tabId);
    
    // Cache results
    cacheAnalysis(url, analysis);
    
    // Update icon and badge
    updateIconFromAnalysis(tabId, analysis);
    
    // Store analysis for popup
    await chrome.storage.local.set({
      [`analysis_${tabId}`]: analysis
    });
    
  } catch (error) {
    console.error('Analysis error:', error);
    updateIcon(tabId, 'red', '!');
  }
}

// Extract page data (runs in page context)
function extractPageData() {
  const data = {
    url: window.location.href,
    title: document.title,
    meta: {},
    headings: {},
    links: [],
    images: [],
    content: {},
    performance: {}
  };
  
  // Extract meta tags
  const metaTags = document.querySelectorAll('meta');
  metaTags.forEach(tag => {
    const name = tag.getAttribute('name') || tag.getAttribute('property');
    const content = tag.getAttribute('content');
    if (name && content) {
      data.meta[name] = content;
    }
  });
  
  // Extract canonical
  const canonical = document.querySelector('link[rel="canonical"]');
  if (canonical) {
    data.meta.canonical = canonical.href;
  }
  
  // Extract headings
  ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].forEach(tag => {
    const elements = document.querySelectorAll(tag);
    data.headings[tag] = Array.from(elements).map(el => ({
      text: el.textContent.trim(),
      html: el.outerHTML
    }));
  });
  
  // Extract links
  const links = document.querySelectorAll('a[href]');
  links.forEach(link => {
    data.links.push({
      href: link.href,
      text: link.textContent.trim(),
      rel: link.rel,
      isInternal: link.hostname === window.location.hostname,
      isExternal: link.hostname !== window.location.hostname
    });
  });
  
  // Extract images
  const images = document.querySelectorAll('img');
  images.forEach(img => {
    data.images.push({
      src: img.src,
      alt: img.alt || '',
      title: img.title || '',
      width: img.naturalWidth,
      height: img.naturalHeight
    });
  });
  
  // Extract content metrics
  const bodyText = document.body.innerText || '';
  data.content.wordCount = bodyText.trim().split(/\s+/).length;
  data.content.charCount = bodyText.length;
  
  // Extract structured data
  const scripts = document.querySelectorAll('script[type="application/ld+json"]');
  data.structuredData = Array.from(scripts).map(script => {
    try {
      return JSON.parse(script.textContent);
    } catch (e) {
      return null;
    }
  }).filter(Boolean);
  
  // Performance data
  if (window.performance && window.performance.timing) {
    const timing = window.performance.timing;
    data.performance.loadTime = timing.loadEventEnd - timing.navigationStart;
    data.performance.domReady = timing.domContentLoadedEventEnd - timing.navigationStart;
  }
  
  return data;
}

// Perform comprehensive SEO analysis
async function performSEOAnalysis(url, pageData, tabId) {
  const issues = {
    errors: [],
    warnings: [],
    info: []
  };
  
  const analysis = {
    url: url,
    timestamp: Date.now(),
    overview: {},
    content: {},
    links: {},
    images: {},
    schema: {},
    performance: {},
    issues: issues,
    score: 100
  };
  
  // Overview analysis
  analysis.overview.title = pageData.title;
  analysis.overview.titleLength = pageData.title.length;
  analysis.overview.description = pageData.meta.description || '';
  analysis.overview.descriptionLength = (pageData.meta.description || '').length;
  analysis.overview.canonical = pageData.meta.canonical || '';
  analysis.overview.robots = pageData.meta.robots || '';
  
  // Check title
  if (!pageData.title) {
    issues.errors.push('Missing title tag');
    analysis.score -= 10;
  } else if (pageData.title.length < 30) {
    issues.warnings.push('Title too short (< 30 characters)');
    analysis.score -= 5;
  } else if (pageData.title.length > 60) {
    issues.warnings.push('Title too long (> 60 characters)');
    analysis.score -= 5;
  }
  
  // Check description
  if (!pageData.meta.description) {
    issues.errors.push('Missing meta description');
    analysis.score -= 10;
  } else if (pageData.meta.description.length < 120) {
    issues.warnings.push('Meta description too short (< 120 characters)');
    analysis.score -= 5;
  } else if (pageData.meta.description.length > 160) {
    issues.warnings.push('Meta description too long (> 160 characters)');
    analysis.score -= 5;
  }
  
  // Content analysis
  analysis.content.wordCount = pageData.content.wordCount;
  analysis.content.headings = pageData.headings;
  
  const h1Count = pageData.headings.h1?.length || 0;
  if (h1Count === 0) {
    issues.errors.push('Missing H1 heading');
    analysis.score -= 10;
  } else if (h1Count > 1) {
    issues.warnings.push(`Multiple H1 headings (${h1Count})`);
    analysis.score -= 5;
  }
  
  if (pageData.content.wordCount < 300) {
    issues.warnings.push('Low word count (< 300 words)');
    analysis.score -= 5;
  }
  
  // Links analysis
  const internalLinks = pageData.links.filter(l => l.isInternal);
  const externalLinks = pageData.links.filter(l => l.isExternal);
  const nofollowLinks = pageData.links.filter(l => l.rel && l.rel.includes('nofollow'));
  
  analysis.links.total = pageData.links.length;
  analysis.links.internal = internalLinks.length;
  analysis.links.external = externalLinks.length;
  analysis.links.nofollow = nofollowLinks.length;
  analysis.links.details = pageData.links;
  
  // Check links (will be done asynchronously)
  analysis.links.checked = false;
  
  // Images analysis
  const imagesWithoutAlt = pageData.images.filter(img => !img.alt);
  analysis.images.total = pageData.images.length;
  analysis.images.withoutAlt = imagesWithoutAlt.length;
  analysis.images.details = pageData.images;
  
  if (imagesWithoutAlt.length > 0) {
    issues.warnings.push(`${imagesWithoutAlt.length} images without alt text`);
    analysis.score -= Math.min(10, imagesWithoutAlt.length * 2);
  }
  
  // Schema analysis
  analysis.schema.found = pageData.structuredData.length > 0;
  analysis.schema.types = pageData.structuredData.map(sd => sd['@type']).filter(Boolean);
  
  if (!analysis.schema.found) {
    issues.info.push('No structured data found');
  }
  
  // Performance
  analysis.performance.loadTime = pageData.performance.loadTime;
  analysis.performance.domReady = pageData.performance.domReady;
  
  // Check Google indexing
  analysis.indexing = {
    checked: false,
    indexed: null
  };
  
  // Start async link checking
  checkLinksAsync(tabId, pageData.links, url);
  
  // Start async indexing check
  checkIndexingAsync(tabId, url);
  
  // Ensure score doesn't go below 0
  analysis.score = Math.max(0, analysis.score);
  
  return analysis;
}

// Check links asynchronously
async function checkLinksAsync(tabId, links, pageUrl) {
  const linkResults = [];
  
  for (const link of links.slice(0, 50)) { // Limit to first 50 links
    try {
      const response = await fetch(link.href, {
        method: 'HEAD',
        mode: 'no-cors'
      });
      
      linkResults.push({
        url: link.href,
        status: response.status,
        ok: response.ok,
        redirected: response.redirected
      });
    } catch (error) {
      linkResults.push({
        url: link.href,
        status: 0,
        ok: false,
        error: error.message
      });
    }
  }
  
  // Update analysis with link results
  const key = `analysis_${tabId}`;
  const stored = await chrome.storage.local.get(key);
  if (stored[key]) {
    stored[key].links.checked = true;
    stored[key].links.results = linkResults;
    
    const broken = linkResults.filter(r => !r.ok && r.status !== 0);
    const redirects = linkResults.filter(r => r.redirected);
    
    if (broken.length > 0) {
      stored[key].issues.errors.push(`${broken.length} broken links found`);
      stored[key].score -= Math.min(15, broken.length * 3);
    }
    
    if (redirects.length > 0) {
      stored[key].issues.warnings.push(`${redirects.length} redirecting links`);
    }
    
    await chrome.storage.local.set({ [key]: stored[key] });
    updateIconFromAnalysis(tabId, stored[key]);
  }
}

// Check Google indexing asynchronously
async function checkIndexingAsync(tabId, url) {
  try {
    const searchUrl = `https://www.google.com/search?q=site:${encodeURIComponent(url)}`;
    const response = await fetch(searchUrl);
    const html = await response.text();
    
    const notIndexedPhrases = [
      'did not match any documents',
      'No results found',
      'Your search did not match'
    ];
    
    const isNotIndexed = notIndexedPhrases.some(phrase => 
      html.toLowerCase().includes(phrase.toLowerCase())
    );
    
    const isIndexed = !isNotIndexed;
    
    // Update analysis
    const key = `analysis_${tabId}`;
    const stored = await chrome.storage.local.get(key);
    if (stored[key]) {
      stored[key].indexing.checked = true;
      stored[key].indexing.indexed = isIndexed;
      
      if (!isIndexed) {
        stored[key].issues.warnings.push('Page not indexed in Google');
        stored[key].score -= 10;
      }
      
      await chrome.storage.local.set({ [key]: stored[key] });
      updateIconFromAnalysis(tabId, stored[key]);
    }
  } catch (error) {
    console.error('Indexing check failed:', error);
  }
}

// Update icon and badge from analysis
function updateIconFromAnalysis(tabId, analysis) {
  const totalIssues = analysis.issues.errors.length + analysis.issues.warnings.length;
  
  let color = 'green';
  if (analysis.issues.errors.length > 0) {
    color = 'red';
  } else if (analysis.issues.warnings.length > 0) {
    color = 'yellow';
  }
  
  updateIcon(tabId, color, totalIssues);
}

// Update icon and badge
function updateIcon(tabId, color, badgeText) {
  const iconPath = {
    16: `icons/icon-${color}-16.png`,
    32: `icons/icon-${color}-32.png`,
    48: `icons/icon-${color}-48.png`,
    128: `icons/icon-${color}-128.png`
  };
  
  chrome.action.setIcon({
    tabId: tabId,
    path: iconPath
  });
  
  // Set badge text - always show if there are issues
  let badge = '';
  if (typeof badgeText === 'number') {
    badge = badgeText === 0 ? '' : String(badgeText);
  } else {
    badge = String(badgeText); // For '...' or other text
  }
  
  chrome.action.setBadgeText({
    tabId: tabId,
    text: badge
  });
  
  // Set badge background color - make it more prominent
  const badgeColors = {
    green: '#16a34a', // Darker green for better visibility
    yellow: '#ea580c', // Orange for warnings
    red: '#dc2626', // Bright red for errors
    gray: '#6b7280' // Medium gray
  };
  
  chrome.action.setBadgeBackgroundColor({
    tabId: tabId,
    color: badgeColors[color] || badgeColors.gray
  });
  
  // Set badge text color to white for better contrast
  chrome.action.setBadgeTextColor({
    tabId: tabId,
    color: '#FFFFFF'
  });
}

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'reanalyze') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        analyzePage(tabs[0].id, tabs[0].url);
        sendResponse({ success: true });
      }
    });
    return true;
  }
  
  if (request.action === 'clearCache') {
    analysisCache.clear();
    chrome.storage.local.clear();
    sendResponse({ success: true });
    return true;
  }
  
  if (request.action === 'getSettings') {
    sendResponse({ settings: settings });
    return true;
  }
  
  if (request.action === 'updateSettings') {
    settings = { ...settings, ...request.settings };
    chrome.storage.sync.set({ settings: settings });
    sendResponse({ success: true });
    return true;
  }
});

