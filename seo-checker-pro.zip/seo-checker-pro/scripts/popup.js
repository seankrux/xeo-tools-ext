// Sean Guillermo AIO Tools - SEO Checker Pro - Popup Script

let currentAnalysis = null;
let currentTabId = null;

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Get current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTabId = tab.id;
    
    // Display URL
    const urlElement = document.getElementById('currentUrl');
    if (urlElement) {
      urlElement.textContent = tab.url || 'No URL';
    }
    
    // Load analysis
    await loadAnalysis();
    
    // Setup event listeners
    setupEventListeners();
  } catch (error) {
    console.error('Initialization error:', error);
    showError('Failed to initialize');
  }
});

// Setup event listeners
function setupEventListeners() {
  // Tab switching
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const tabName = tab.dataset.tab;
      switchTab(tabName);
    });
  });
  
  // Reanalyze button
  const reanalyzeBtn = document.getElementById('reanalyzeBtn');
  if (reanalyzeBtn) {
    reanalyzeBtn.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'reanalyze' });
      showLoading();
      setTimeout(() => loadAnalysis(), 2000);
    });
  }
  
  // Toggle headings
  const toggleHeadings = document.getElementById('toggleHeadings');
  if (toggleHeadings) {
    toggleHeadings.addEventListener('click', () => {
      chrome.tabs.sendMessage(currentTabId, { action: 'toggleHeadings' });
    });
  }
  
  // Toggle links
  const toggleLinks = document.getElementById('toggleLinks');
  if (toggleLinks) {
    toggleLinks.addEventListener('click', () => {
      chrome.tabs.sendMessage(currentTabId, { action: 'toggleLinks' });
    });
  }
  
  // Settings button
  const settingsBtn = document.getElementById('settingsBtn');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    });
  }
}

// Switch tab
function switchTab(tabName) {
  // Update tab buttons
  document.querySelectorAll('.tab').forEach(tab => {
    tab.classList.remove('active');
    if (tab.dataset.tab === tabName) {
      tab.classList.add('active');
    }
  });
  
  // Update content
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.remove('active');
    if (content.id === tabName) {
      content.classList.add('active');
    }
  });
}

// Load analysis from storage
async function loadAnalysis() {
  try {
    const key = `analysis_${currentTabId}`;
    const result = await chrome.storage.local.get(key);
    
    if (result[key]) {
      currentAnalysis = result[key];
      console.log('Loaded analysis:', currentAnalysis);
      displayAnalysis(currentAnalysis);
    } else {
      showEmptyState();
    }
  } catch (error) {
    console.error('Error loading analysis:', error);
    showError('Failed to load analysis');
  }
}

// Display analysis
function displayAnalysis(analysis) {
  if (!analysis) {
    showEmptyState();
    return;
  }
  
  // Update score
  updateScore(analysis.score || 0);
  
  // Update meta tab
  updateMetaTab(analysis);
  
  // Update headings tab
  updateHeadingsTab(analysis);
  
  // Update links tab
  updateLinksTab(analysis);
  
  // Update images tab
  updateImagesTab(analysis);
  
  // Update schema tab
  updateSchemaTab(analysis);
  
  // Update tab badges
  updateBadges(analysis);
}

// Update score
function updateScore(score) {
  const scoreValue = document.getElementById('scoreValue');
  if (scoreValue) {
    scoreValue.textContent = Math.round(score);
  }
}

// Update meta tab
function updateMetaTab(analysis) {
  // Title
  const titleLength = document.getElementById('titleLength');
  const titleStatus = document.getElementById('titleStatus');
  if (titleLength && analysis.overview) {
    const len = analysis.overview.titleLength || 0;
    titleLength.textContent = len;
    if (titleStatus) {
      if (len === 0) {
        titleStatus.textContent = 'Missing';
        titleStatus.className = 'metric-status danger';
      } else if (len < 30 || len > 60) {
        titleStatus.textContent = 'Not optimal';
        titleStatus.className = 'metric-status warning';
      } else {
        titleStatus.textContent = 'Good';
        titleStatus.className = 'metric-status success';
      }
    }
  }
  
  // Description
  const descLength = document.getElementById('descLength');
  const descStatus = document.getElementById('descStatus');
  if (descLength && analysis.overview) {
    const len = analysis.overview.descriptionLength || 0;
    descLength.textContent = len;
    if (descStatus) {
      if (len === 0) {
        descStatus.textContent = 'Missing';
        descStatus.className = 'metric-status danger';
      } else if (len < 120 || len > 160) {
        descStatus.textContent = 'Not optimal';
        descStatus.className = 'metric-status warning';
      } else {
        descStatus.textContent = 'Good';
        descStatus.className = 'metric-status success';
      }
    }
  }
  
  // Word count
  const wordCount = document.getElementById('wordCount');
  const wordStatus = document.getElementById('wordStatus');
  if (wordCount && analysis.content) {
    const count = analysis.content.wordCount || 0;
    wordCount.textContent = count;
    if (wordStatus) {
      if (count < 300) {
        wordStatus.textContent = 'Low';
        wordStatus.className = 'metric-status warning';
      } else {
        wordStatus.textContent = 'Good';
        wordStatus.className = 'metric-status success';
      }
    }
  }
  
  // Load time
  const loadTime = document.getElementById('loadTime');
  const loadStatus = document.getElementById('loadStatus');
  if (loadTime && analysis.performance) {
    const time = analysis.performance.loadTime || 0;
    loadTime.textContent = time + 'ms';
    if (loadStatus) {
      if (time > 3000) {
        loadStatus.textContent = 'Slow';
        loadStatus.className = 'metric-status warning';
      } else {
        loadStatus.textContent = 'Fast';
        loadStatus.className = 'metric-status success';
      }
    }
  }
  
  // Meta information
  const metaInfo = document.getElementById('metaInfo');
  if (metaInfo && analysis.overview) {
    metaInfo.innerHTML = '';
    
    const metaItems = [
      { label: 'Title', value: analysis.overview.title || 'Not set' },
      { label: 'Description', value: analysis.overview.description || 'Not set' },
      { label: 'Canonical', value: analysis.overview.canonical || 'Not set' },
      { label: 'Robots', value: analysis.overview.robots || 'Not set' }
    ];
    
    metaItems.forEach(item => {
      const div = document.createElement('div');
      div.className = 'meta-item';
      div.innerHTML = `
        <div class="meta-label">${item.label}</div>
        <div class="meta-value">${item.value}</div>
      `;
      metaInfo.appendChild(div);
    });
  }
  
  // Issues list
  const issuesList = document.getElementById('issuesList');
  if (issuesList && analysis.issues) {
    issuesList.innerHTML = '';
    
    const allIssues = [
      ...(analysis.issues.errors || []).map(e => ({ type: 'error', text: e })),
      ...(analysis.issues.warnings || []).map(w => ({ type: 'warning', text: w }))
    ];
    
    if (allIssues.length === 0) {
      issuesList.innerHTML = '<div class="empty-state">No issues found! ✓</div>';
    } else {
      allIssues.forEach(issue => {
        const item = document.createElement('div');
        item.className = `issue-item ${issue.type}`;
        item.innerHTML = `
          <div class="issue-title">${issue.type === 'error' ? '❌' : '⚠️'} ${issue.type.toUpperCase()}</div>
          <div class="issue-description">${issue.text}</div>
        `;
        issuesList.appendChild(item);
      });
    }
  }
}

// Update headings tab
function updateHeadingsTab(analysis) {
  const headingsOutline = document.getElementById('headingsOutline');
  if (!headingsOutline || !analysis.content || !analysis.content.headings) {
    if (headingsOutline) {
      headingsOutline.innerHTML = '<div class="empty-state">No headings found</div>';
    }
    return;
  }
  
  headingsOutline.innerHTML = '';
  
  // Build headings outline from h1-h6
  const headingLevels = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
  let totalHeadings = 0;
  
  headingLevels.forEach(level => {
    const headings = analysis.content.headings[level] || [];
    headings.forEach(heading => {
      const item = document.createElement('div');
      item.className = 'heading-item';
      item.style.paddingLeft = (parseInt(level.charAt(1)) - 1) * 12 + 'px';
      item.innerHTML = `
        <span class="heading-tag">${level.toUpperCase()}</span>
        <span class="heading-text">${heading.text || '(empty)'}</span>
      `;
      headingsOutline.appendChild(item);
      totalHeadings++;
    });
  });
  
  if (totalHeadings === 0) {
    headingsOutline.innerHTML = '<div class="empty-state">No headings found</div>';
  }
}

// Update links tab
function updateLinksTab(analysis) {
  if (!analysis.links) {
    return;
  }
  
  // Update metrics
  const totalLinks = document.getElementById('totalLinks');
  const internalLinks = document.getElementById('internalLinks');
  const externalLinks = document.getElementById('externalLinks');
  const nofollowLinks = document.getElementById('nofollowLinks');
  
  if (totalLinks) totalLinks.textContent = analysis.links.total || 0;
  if (internalLinks) internalLinks.textContent = analysis.links.internal || 0;
  if (externalLinks) externalLinks.textContent = analysis.links.external || 0;
  if (nofollowLinks) nofollowLinks.textContent = analysis.links.nofollow || 0;
  
  // Display link details
  const linksList = document.getElementById('linksList');
  if (linksList && analysis.links.details) {
    linksList.innerHTML = '';
    
    const links = analysis.links.details.slice(0, 20); // Show first 20 links
    
    if (links.length === 0) {
      linksList.innerHTML = '<div class="empty-state">No links found</div>';
    } else {
      links.forEach(link => {
        const item = document.createElement('div');
        item.className = 'link-item';
        const type = link.isInternal ? 'Internal' : 'External';
        const nofollow = link.rel && link.rel.includes('nofollow') ? ' (nofollow)' : '';
        item.innerHTML = `
          <div class="link-url">${link.href}</div>
          <div class="link-meta">${type}${nofollow} · ${link.text.substring(0, 50) || 'No text'}</div>
        `;
        linksList.appendChild(item);
      });
      
      if (analysis.links.total > 20) {
        const more = document.createElement('div');
        more.className = 'empty-state';
        more.textContent = `... and ${analysis.links.total - 20} more links`;
        linksList.appendChild(more);
      }
    }
  }
}

// Update images tab
function updateImagesTab(analysis) {
  if (!analysis.images) {
    return;
  }
  
  // Update metrics
  const totalImages = document.getElementById('totalImages');
  const imagesNoAlt = document.getElementById('imagesNoAlt');
  
  if (totalImages) totalImages.textContent = analysis.images.total || 0;
  if (imagesNoAlt) imagesNoAlt.textContent = analysis.images.withoutAlt || 0;
  
  // Display image details
  const imagesList = document.getElementById('imagesList');
  if (imagesList && analysis.images.details) {
    imagesList.innerHTML = '';
    
    const images = analysis.images.details.slice(0, 10); // Show first 10 images
    
    if (images.length === 0) {
      imagesList.innerHTML = '<div class="empty-state">No images found</div>';
    } else {
      images.forEach(img => {
        const item = document.createElement('div');
        item.className = 'image-item';
        const altStatus = img.alt ? '✓ Has alt' : '❌ Missing alt';
        const altClass = img.alt ? 'success' : 'danger';
        item.innerHTML = `
          <div class="image-preview">
            <img src="${img.src}" alt="${img.alt || 'No alt'}" style="max-width:60px;max-height:60px;border-radius:4px">
          </div>
          <div class="image-info">
            <div class="image-url">${img.src.substring(0, 50)}...</div>
            <div class="image-meta metric-status ${altClass}">${altStatus}</div>
          </div>
        `;
        imagesList.appendChild(item);
      });
      
      if (analysis.images.total > 10) {
        const more = document.createElement('div');
        more.className = 'empty-state';
        more.textContent = `... and ${analysis.images.total - 10} more images`;
        imagesList.appendChild(more);
      }
    }
  }
}

// Update schema tab
function updateSchemaTab(analysis) {
  const schemaInfo = document.getElementById('schemaInfo');
  if (!schemaInfo) return;
  
  if (!analysis.schema || !analysis.schema.found) {
    schemaInfo.innerHTML = '<div class="empty-state">No structured data found</div>';
    return;
  }
  
  schemaInfo.innerHTML = '';
  
  const card = document.createElement('div');
  card.className = 'metric-card';
  card.innerHTML = `
    <div class="metric-label">Schema Types Found</div>
    <div class="metric-value">${analysis.schema.types?.length || 0}</div>
    <div class="metric-status success">Structured data detected</div>
  `;
  schemaInfo.appendChild(card);
  
  if (analysis.schema.types && analysis.schema.types.length > 0) {
    const typesList = document.createElement('div');
    typesList.style.marginTop = '12px';
    analysis.schema.types.forEach(type => {
      const typeItem = document.createElement('div');
      typeItem.className = 'schema-type';
      typeItem.style.padding = '8px';
      typeItem.style.background = 'var(--bg-secondary)';
      typeItem.style.border = '1px solid var(--border-subtle)';
      typeItem.style.borderRadius = '6px';
      typeItem.style.marginBottom = '6px';
      typeItem.textContent = type;
      typesList.appendChild(typeItem);
    });
    schemaInfo.appendChild(typesList);
  }
}

// Update tab badges
function updateBadges(analysis) {
  if (!analysis.issues) return;
  
  const errorCount = analysis.issues.errors?.length || 0;
  const warningCount = analysis.issues.warnings?.length || 0;
  const totalIssues = errorCount + warningCount;
  
  // Meta badge
  const metaBadge = document.getElementById('metaBadge');
  if (metaBadge && totalIssues > 0) {
    metaBadge.textContent = totalIssues;
    metaBadge.style.display = 'inline-flex';
  }
  
  // Headings badge
  if (analysis.content && analysis.content.headings) {
    const headingsBadge = document.getElementById('headingsBadge');
    const h1Count = analysis.content.headings.h1?.length || 0;
    if (headingsBadge && (h1Count === 0 || h1Count > 1)) {
      headingsBadge.textContent = h1Count === 0 ? '!' : h1Count;
      headingsBadge.style.display = 'inline-flex';
    }
  }
  
  // Images badge
  if (analysis.images) {
    const imagesBadge = document.getElementById('imagesBadge');
    const imageIssues = analysis.images.withoutAlt || 0;
    if (imagesBadge && imageIssues > 0) {
      imagesBadge.textContent = imageIssues;
      imagesBadge.style.display = 'inline-flex';
    }
  }
}

// Show loading state
function showLoading() {
  const scoreValue = document.getElementById('scoreValue');
  if (scoreValue) scoreValue.textContent = '...';
  
  const issuesList = document.getElementById('issuesList');
  if (issuesList) {
    issuesList.innerHTML = '<div class="empty-state">Analyzing page...</div>';
  }
}

// Show empty state
function showEmptyState() {
  const scoreValue = document.getElementById('scoreValue');
  if (scoreValue) scoreValue.textContent = '--';
  
  const issuesList = document.getElementById('issuesList');
  if (issuesList) {
    issuesList.innerHTML = '<div class="empty-state">Click "Reanalyze Page" to start analysis</div>';
  }
}

// Show error
function showError(message) {
  const issuesList = document.getElementById('issuesList');
  if (issuesList) {
    issuesList.innerHTML = `<div class="empty-state" style="color:var(--danger)">${message}</div>`;
  }
}

