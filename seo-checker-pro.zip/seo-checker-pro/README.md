# SEO Checker Pro

A comprehensive Chrome extension for SEO analysis with on-page highlighting, link checking, and real-time Google indexing verification.

## Features

### 🎯 Core Features

- **Auto-Analysis on Page Load** - Automatically analyzes every page you visit
- **SEO Score (0-100)** - Visual score ring showing overall page quality
- **Issue Count Badge** - Icon shows number of errors/warnings at a glance
- **Smart Caching** - Saves results to avoid re-checking pages
- **Dark Theme** - Modern Linear-style dark interface

### 🎨 Visual Indicators

**Icon Colors:**
- 🟢 **Green** - No errors, good SEO
- 🟡 **Yellow** - Warnings detected
- 🔴 **Red** - Critical errors found
- ⚪ **Gray** - Analyzing or no data

**Badge Overlay:**
- Shows total number of issues (errors + warnings)
- Updates automatically when page is analyzed

### 📊 Analysis Tabs

#### Overview Tab
- Title length validation (30-60 chars optimal)
- Meta description length (120-160 chars optimal)
- Word count
- Page load time
- Complete issues list (errors, warnings, info)

#### Content Tab
- Headings structure (H1-H6)
- **Toggle headings highlighter** - Highlights all headings on page with color-coded labels
- H1 validation (should have exactly 1)
- Word count analysis

#### Links Tab
- Total links count
- Internal vs external links
- Nofollow links detection
- **Toggle links highlighter** - Highlights all links with status indicators:
  - 🟢 Green solid border = Working link (200 OK)
  - 🟠 Orange solid border = Redirect (301/302)
  - 🔴 Red solid border = Broken link (404/500)
  - Solid border = Internal link
  - Dashed border = External link

#### Images Tab
- Total images count
- Images missing alt text
- Image optimization warnings

#### Schema Tab
- Structured data detection
- Schema.org types found
- JSON-LD validation

### ⚙️ Settings

**Analysis Settings:**
- Auto-check pages on load
- Auto-highlight links
- Auto-highlight headings

**Cache Settings:**
- Enable/disable caching
- Cache duration (30 min - 24 hours)
- Clear cache button

### 🔍 SEO Checks Performed

**Meta Tags:**
- Title tag presence and length
- Meta description presence and length
- Meta robots (noindex/nofollow)
- Canonical URL

**Content:**
- H1 heading (must have exactly 1)
- Headings hierarchy (H1-H6)
- Word count (minimum 300 recommended)
- Text-to-code ratio

**Links:**
- Internal links
- External links
- Nofollow links
- Link status checking (200/301/302/404)

**Images:**
- Alt text presence
- Image optimization

**Technical:**
- Page load time
- Structured data (Schema.org)
- Google indexing status (via site: search)

## Installation

1. Download and extract `seo-checker-pro.zip`
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" (toggle in top-right)
4. Click "Load unpacked"
5. Select the `seo-checker-pro` folder
6. Pin the extension by clicking the puzzle icon (🧩) in your toolbar

## Usage

### Basic Usage

1. **Automatic Analysis**: Simply browse any website - the extension automatically analyzes it
2. **Check Icon**: Look at the extension icon to see status:
   - Color indicates overall health (green/yellow/red)
   - Badge number shows total issues
3. **Open Popup**: Click the icon to see detailed analysis
4. **Switch Tabs**: Navigate between Overview, Content, Links, Images, and Schema tabs

### Highlighting Features

**Headings Highlighter:**
1. Open the extension popup
2. Go to "Content" tab
3. Click "Highlight" button
4. All headings on the page will be outlined with color-coded labels:
   - H1 = Red
   - H2 = Orange
   - H3 = Yellow
   - H4 = Green
   - H5 = Blue
   - H6 = Purple

**Links Highlighter:**
1. Open the extension popup
2. Go to "Links" tab
3. Click "Highlight" button
4. All links will be outlined with status indicators:
   - Green = Working (200)
   - Orange = Redirect (301/302)
   - Red = Broken (404/500)
   - Solid border = Internal
   - Dashed border = External

### Settings

1. Click the "Settings" button in the popup
2. Configure your preferences:
   - Enable/disable auto-check
   - Enable/disable auto-highlighting
   - Set cache duration
   - Clear cache if needed
3. Click "Save Settings"

## How It Works

### Analysis Process

1. **Page Load Detection**: Extension detects when a page finishes loading
2. **Data Extraction**: Content script extracts all SEO-relevant data:
   - Meta tags, headings, links, images
   - Structured data, performance metrics
3. **Analysis**: Background worker analyzes data and calculates SEO score
4. **Caching**: Results are cached to avoid re-checking
5. **Icon Update**: Icon color and badge update based on findings
6. **Popup Display**: Detailed results available in popup

### Google Indexing Check

The extension checks if a page is indexed in Google by:
1. Performing a Google search with `site:exact-url.com`
2. Parsing the results page
3. Detecting "did not match any documents" = not indexed
4. Detecting search results = indexed

### Link Status Checking

When links are highlighted, the extension:
1. Sends HEAD requests to each link
2. Checks HTTP status codes
3. Detects redirects (301/302)
4. Identifies broken links (404/500)
5. Color-codes based on status

## Privacy

- **No data collection**: All analysis happens locally in your browser
- **No external servers**: No data is sent to any external servers
- **No tracking**: The extension does not track your browsing
- **Cache is local**: All cached data is stored locally in Chrome storage

## Technical Details

- **Manifest Version**: 3 (latest Chrome extension standard)
- **Permissions**: activeTab, tabs, storage, scripting, webRequest
- **Storage**: Chrome local storage for cache, sync storage for settings
- **Architecture**: Background service worker + content scripts + popup UI

## Troubleshooting

**Extension not working:**
- Make sure you're on an http:// or https:// page
- Local files (file://) and Chrome pages (chrome://) cannot be analyzed
- Try clicking "Reanalyze" button

**Highlighting not working:**
- Make sure the page has finished loading
- Some websites may block content script injection
- Try refreshing the page

**Cache issues:**
- Go to Settings and click "Clear Cache"
- Disable caching if you want fresh analysis every time

## Version

**1.0.0** - Initial release

## License

MIT License

